export const firebase = {
  db: null,
  storage: null,
  auth: null,
  collection() {
    throw new Error('Firebase není v sandboxu inicializované.');
  }
};

// Pokud chceš v Gemini mockovat data, můžeš tuhle funkci nahradit
// jednoduchým polem objektů a upravit notes-lab.js tak, aby používal
// lokální úložiště místo Firestore.
